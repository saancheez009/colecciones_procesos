"""Crea con un editor el fichero de texto Alumnos.txt y escribe en él los nombres, edades y estaturas de los alumnos de un grupo, cada uno en una línea:
	juan 22 1.77
	luis 21 1.80
	pedro 20 1.73
	…"""


