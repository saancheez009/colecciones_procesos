class   Empleado():
    def __init__(self,nombre):
        sefl.nombre= nombre


    def 